import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import random
import subprocess
import time
import torch
from models import build_pair
from dataset import load_database,collate,metrics

ROOT=Path(__file__).resolve().parents[1]


@torch.no_grad()
def evaluate(model,graphs,scale,device):
    model.eval(); predictions=[]; targets=[]
    for start in range(0,len(graphs),32):
        x,y=collate(graphs[start:start+32],device,scale)
        predictions.append(model(**x).cpu()); targets.append(y.cpu())
    pred,target=torch.cat(predictions),torch.cat(targets)
    return {key:float(value.mean()) for key,value in metrics(pred,target).items()}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--config',required=True)
    ap.add_argument('--seed',type=int,required=True)
    ap.add_argument('--device',default='cuda')
    ap.add_argument('--max-epochs',type=int)
    args=ap.parse_args()
    torch.set_num_threads(2)
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    grid=json.loads((ROOT/'configs/grid.json').read_text())
    cfg=next(c for c in grid['configs'] if c['name']==args.config)
    train_cfg=grid['shared_training'].copy()
    if args.max_epochs: train_cfg['max_epochs']=args.max_epochs
    manifest=json.loads((ROOT/'data/manifest.json').read_text())
    graphs=load_database(ROOT/'data/qm9s_uv1000.json.gz')
    # Test labels are stored but never collated, scored, or used for selection here.
    train=[g for g in graphs if g['split']=='train']
    val=[g for g in graphs if g['split']=='validation']
    del graphs
    scale=manifest['train_spectrum_rms']
    models,counts=build_pair(cfg,manifest['train_median_atoms'],seed=args.seed)
    for key,value in models['baseline'].backbone.state_dict().items():
        if not torch.equal(value,models['mto'].backbone.state_dict()[key]): raise AssertionError('Backbone initialization differs')
    folder=ROOT/'runs'/f'{args.config}_seed{args.seed}'
    folder.mkdir(parents=True,exist_ok=True)
    sync_base=os.environ.get('MTO_SYNC_ROOT')
    sync_dir=f'{sync_base}/{folder.name}' if sync_base else None
    if sync_dir:
        subprocess.run(['ssh','-oBatchMode=yes','ln01','mkdir','-p',sync_dir],check=True)
    def sync_files(paths):
        if sync_dir:
            subprocess.run(['scp','-q','-oBatchMode=yes',*[str(p) for p in paths],f'ln01:{sync_dir}/'],check=True)
    experiment={'config':cfg,'training':train_cfg,'seed':args.seed,'counts':counts,
                'database_sha256':manifest['sample_sha256'],'inputs':['z','pos','radius_edges'],
                'labels':['spectrum'],'device':args.device,'gpu':torch.cuda.get_device_name() if args.device=='cuda' else None,
                'test_evaluated':False,'torch':str(torch.__version__),
                'source_hashes':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                                 for p in list((ROOT/'src').rglob('*.py'))+[Path(__file__)]}}
    experiment['config_sha256']=hashlib.sha256(json.dumps(experiment,sort_keys=True).encode()).hexdigest()
    (folder/'experiment.json').write_text(json.dumps(experiment,indent=2))
    sync_files([folder/'experiment.json'])
    print(json.dumps(experiment,indent=2),flush=True)
    for variant in (['baseline','mto'] if args.seed%4==3 else ['mto','baseline']):
        torch.manual_seed(args.seed); random.seed(args.seed)
        model=models[variant].to(args.device)
        optimizer=torch.optim.AdamW(model.parameters(),lr=cfg['lr'],weight_decay=train_cfg['weight_decay'])
        best=float('inf'); stale=0; history=[]; started=time.time()
        if args.device=='cuda': torch.cuda.reset_peak_memory_stats()
        for epoch in range(train_cfg['max_epochs']):
            model.train()
            warm=train_cfg['warmup_epochs']; total=train_cfg['max_epochs']
            mult=(epoch+1)/warm if epoch<warm else 0.05+0.95*(1+math.cos(math.pi*(epoch-warm)/max(1,total-warm)))/2
            for group in optimizer.param_groups: group['lr']=cfg['lr']*mult
            order=list(range(len(train))); random.Random(args.seed*10000+epoch).shuffle(order)
            train_loss=0.; batches=0
            for offset in range(0,len(train),train_cfg['batch_size']):
                rows=[train[i] for i in order[offset:offset+train_cfg['batch_size']]]
                x,y=collate(rows,args.device,scale)
                pred=model(**x); loss=(pred-y).square().mean()
                if not bool(torch.isfinite(loss)): raise FloatingPointError(f'{variant}: nonfinite loss')
                optimizer.zero_grad(set_to_none=True); loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(),train_cfg['gradient_clip'],error_if_nonfinite=True)
                optimizer.step(); train_loss+=float(loss)*len(rows); batches+=1
            validation=evaluate(model,val,scale,args.device)
            row={'epoch':epoch+1,'train_mse':train_loss/len(train),'validation':validation,
                 'elapsed_seconds':time.time()-started,'lr':cfg['lr']*mult}
            history.append(row)
            if validation['mse']<best:
                best=validation['mse']; stale=0; best_epoch=epoch+1
                state={k:v.detach().cpu() for k,v in model.state_dict().items()}
                torch.save({'state_dict':state,'variant':variant,'config':cfg,'counts':counts,'seed':args.seed,
                            'n_ref':manifest['train_median_atoms'],'scale':scale,'best_epoch':best_epoch,
                            'validation':validation,'database_sha256':manifest['sample_sha256']},folder/f'{variant}_best.pt')
            else: stale+=1
            if epoch%10==0 or epoch==total-1:
                print(json.dumps({'variant':variant,**row}),flush=True)
                (folder/f'{variant}_history.json').write_text(json.dumps(history,indent=2))
                sync_files([folder/f'{variant}_history.json'])
            if epoch+1>=train_cfg['min_epochs'] and stale>=train_cfg['patience']: break
        (folder/f'{variant}_history.json').write_text(json.dumps(history,indent=2))
        result={'variant':variant,'best_validation_mse':best,'best_epoch':best_epoch,'epochs_run':epoch+1,
                'parameters':counts[variant],'elapsed_seconds':time.time()-started,
                'peak_gpu_memory_bytes':torch.cuda.max_memory_allocated() if args.device=='cuda' else None,
                'test_evaluated':False}
        (folder/f'{variant}_summary.json').write_text(json.dumps(result,indent=2))
        sync_files([folder/f'{variant}_summary.json',folder/f'{variant}_history.json',folder/f'{variant}_best.pt'])
        print(json.dumps(result),flush=True)
        models[variant]=model.cpu()
        del optimizer
        if args.device=='cuda': torch.cuda.empty_cache()
    (folder/'DONE').write_text('Both arms completed; no test evaluation performed.\n')
    sync_files([folder/'DONE'])


if __name__=='__main__': main()
