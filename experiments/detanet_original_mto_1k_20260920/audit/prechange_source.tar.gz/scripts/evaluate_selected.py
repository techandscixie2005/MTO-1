"""Open fixed test only after validation selection and all paired fits complete."""
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
import statistics
import torch
from models import build_pair
from dataset import load_database,collate,metrics

ROOT=Path(__file__).resolve().parents[1]


def main():
    torch.set_num_threads(1)
    selection=json.loads((ROOT/'results/selection.json').read_text())
    grid=json.loads((ROOT/'configs/grid.json').read_text())
    manifest=json.loads((ROOT/'data/manifest.json').read_text())
    name=selection['selected_config']
    cfg=next(c for c in grid['configs'] if c['name']==name)
    seeds=grid['seeds']+grid['confirmatory_seeds']
    for seed in seeds:
        if not (ROOT/'runs'/f'{name}_seed{seed}'/'DONE').exists(): raise SystemExit(f'Incomplete seed {seed}')
    if selection['database_sha256']!=manifest['sample_sha256']: raise ValueError('Database changed after selection')
    graphs=load_database(ROOT/'data/qm9s_uv1000.json.gz')
    test=[g for g in graphs if g['split']=='test']
    train=[g for g in graphs if g['split']=='train']
    scale=manifest['train_spectrum_rms']; predictions={}; per_molecule=[]; per_seed=[]
    for seed in seeds:
        pair,counts=build_pair(cfg,manifest['train_median_atoms'],seed=seed)
        for arm,model in pair.items():
            path=ROOT/'runs'/f'{name}_seed{seed}'/f'{arm}_best.pt'
            ckpt=torch.load(path,map_location='cpu',weights_only=True)
            if ckpt['database_sha256']!=manifest['sample_sha256']: raise ValueError('Checkpoint database mismatch')
            model.load_state_dict(ckpt['state_dict']); model.eval()
            ps=[]; ys=[]
            with torch.no_grad():
                for offset in range(0,len(test),32):
                    x,y=collate(test[offset:offset+32],scale=scale)
                    ps.append(model(**x)); ys.append(y)
            pred,target=torch.cat(ps),torch.cat(ys)
            m=metrics(pred,target)
            summary={'seed':seed,'arm':arm,'config':name,'parameters':counts[arm],
                     'best_epoch':ckpt['best_epoch'],'validation_mse':ckpt['validation']['mse'],
                     **{key:float(value.mean()) for key,value in m.items()}}
            summary.update(source_mse=summary['mse']*scale**2,source_rmse=summary['rmse']*scale,source_mae=summary['mae']*scale)
            per_seed.append(summary)
            for index,g in enumerate(test):
                per_molecule.append({'id':g['id'],'identity':g['identity'],'seed':seed,'arm':arm,
                                     **{key:float(value[index]) for key,value in m.items()}})
            predictions[f'{arm}_{seed}']=pred.tolist()
    mean_target=torch.stack([g['spectrum'] for g in train]).mean(0)/scale
    naive=metrics(mean_target[None].expand(len(test),-1),target)
    aggregate={}
    for arm in ('baseline','mto'):
        records=[r for r in per_seed if r['arm']==arm]
        aggregate[arm]={}
        for metric in ['mse','rmse','mae','cosine','pearson','source_mse','source_rmse']:
            values=[r[metric] for r in records]
            aggregate[arm][metric]={'mean':statistics.mean(values),'std_across_seeds':statistics.stdev(values)}
    # Paired molecular bootstrap after averaging seed-specific error differences.
    # This CI conditions on the fixed training set and is not a full population CI.
    differences=[]
    for g in test:
        rows=[r for r in per_molecule if r['id']==g['id']]
        differences.append(statistics.mean(r['mse'] for r in rows if r['arm']=='mto')-
                           statistics.mean(r['mse'] for r in rows if r['arm']=='baseline'))
    diffs=torch.tensor(differences,dtype=torch.float64)
    gen=torch.Generator().manual_seed(20260913)
    samples=torch.randint(len(diffs),(10000,len(diffs)),generator=gen)
    boot=diffs[samples].mean(1)
    ci=torch.quantile(boot,torch.tensor([0.025,0.975],dtype=torch.float64)).tolist()
    b=aggregate['baseline']['mse']['mean']; m=aggregate['mto']['mse']['mean']
    report={'selected_config':name,'selection_sha256':selection['selection_sha256'],'seeds':seeds,
            'test_molecules':len(test),'aggregate':aggregate,'per_seed':per_seed,
            'train_mean_spectrum_baseline':{k:float(v.mean()) for k,v in naive.items()},
            'mto_mse_relative_improvement_percent':100*(b-m)/b,
            'paired_mto_minus_baseline_mse':float(diffs.mean()),'paired_molecule_bootstrap_95ci':ci,
            'ci_scope':'seed-averaged paired test molecules; fixed train/val/test split, conditional on fitted models',
            'mto_better_test_mse_seed_count':sum(next(r['mse'] for r in per_seed if r['arm']=='mto' and r['seed']==s)<
                                               next(r['mse'] for r in per_seed if r['arm']=='baseline' and r['seed']==s) for s in seeds),
            'database_sha256':manifest['sample_sha256'],'test_used_for_tuning':False,
            'interpretation_scope':'1000 molecules, one random split, direct-spectrum readouts; no claim of real orbitals or universal benefit'}
    out=ROOT/'results'
    (out/'comparison.json').write_text(json.dumps(report,indent=2))
    with (out/'per_seed.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(per_seed[0])); writer.writeheader(); writer.writerows(per_seed)
    with (out/'per_molecule.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(per_molecule[0])); writer.writeheader(); writer.writerows(per_molecule)
    bundle={'ids':[g['id'] for g in test],'energy_eV':manifest['energy_grid_eV'],
            'target':target.tolist(),'predictions':predictions,'normalization_scale':scale}
    with gzip.open(out/'test_predictions.json.gz','wt') as f: json.dump(bundle,f)
    print(json.dumps(report,indent=2),flush=True)
    from report_results import make_report
    print('Backup archive:',make_report(),flush=True)


if __name__=='__main__': main()
