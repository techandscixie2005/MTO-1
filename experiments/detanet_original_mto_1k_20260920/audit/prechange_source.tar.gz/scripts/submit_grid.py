import json
from pathlib import Path
import subprocess

root=Path(__file__).resolve().parents[1]
grid=json.loads((root/'configs/grid.json').read_text())
if not (root/'data/manifest.json').exists(): raise SystemExit('Prepare and audit the database first')
test=json.loads((root/'results/model_tests.json').read_text())
if not test['passed']: raise SystemExit('Model tests must pass before submitting experiments')
target=root/'jobs/pilot.json'
if target.exists(): raise SystemExit('Job registry already exists; refusing duplicate submission')
target.parent.mkdir(exist_ok=True)
jobs=[]
for cfg in grid['configs']:
    for seed in grid['seeds']:
        result=subprocess.run(['sbatch','--parsable','scripts/train.slurm',cfg['name'],str(seed)],
                              cwd=root,check=True,capture_output=True,text=True)
        jobs.append({'config':cfg['name'],'seed':seed,'job_id':result.stdout.strip().split(';')[0]})
        target.write_text(json.dumps(jobs,indent=2))
        print(jobs[-1],flush=True)
