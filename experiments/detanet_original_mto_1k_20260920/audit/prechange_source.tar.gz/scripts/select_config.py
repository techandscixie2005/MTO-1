"""Validation-only selection, frozen before test evaluation."""
import hashlib,json
from pathlib import Path

root=Path(__file__).resolve().parents[1]
grid=json.loads((root/'configs/grid.json').read_text())
table=[]
for cfg in grid['configs']:
    values=[]; details=[]
    for seed in grid['seeds']:
        folder=root/'runs'/f"{cfg['name']}_seed{seed}"
        if not (folder/'DONE').exists(): raise SystemExit(f'Incomplete pilot pair: {folder.name}')
        for arm in ('baseline','mto'):
            result=json.loads((folder/f'{arm}_summary.json').read_text())
            values.append(result['best_validation_mse'])
            details.append({'arm':arm,'seed':seed,**result})
    table.append({'config':cfg['name'],'joint_validation_mse':sum(values)/len(values),'details':details})
selected=min(table,key=lambda row:row['joint_validation_mse'])['config']
record={'selected_config':selected,'rule':grid['selection_rule'],'selection_used_test':False,
        'pilot_seeds':grid['seeds'],'confirmatory_seeds':grid['confirmatory_seeds'],
        'validation_results':table,'database_sha256':json.loads((root/'data/manifest.json').read_text())['sample_sha256']}
record['selection_sha256']=hashlib.sha256(json.dumps(record,sort_keys=True).encode()).hexdigest()
out=root/'results/selection.json'
if out.exists() and json.loads(out.read_text())!=record: raise SystemExit('Selection already frozen with different results')
out.write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
