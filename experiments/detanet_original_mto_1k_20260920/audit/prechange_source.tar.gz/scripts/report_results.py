"""Create inspectable figures, a concise Chinese report, and a backup archive."""
import gzip
import json
from pathlib import Path
import tarfile

ROOT=Path(__file__).resolve().parents[1]


def make_report():
    import numpy as np
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    r=json.loads((ROOT/'results/comparison.json').read_text())
    with gzip.open(ROOT/'results/test_predictions.json.gz','rt') as f: bundle=json.load(f)
    out=ROOT/'results'; colors={'baseline':'#476a93','mto':'#c96532'}
    fig,axes=plt.subplots(1,3,figsize=(12,3.8))
    for ax,key,title in zip(axes,['mse','cosine','pearson'],['Normalized test MSE (lower better)','Cosine similarity (higher better)','Pearson correlation (higher better)']):
        means=[r['aggregate'][arm][key]['mean'] for arm in colors]
        errors=[r['aggregate'][arm][key]['std_across_seeds'] for arm in colors]
        ax.bar(['DetaNet','DetaNet + MTO'],means,yerr=errors,capsize=5,color=list(colors.values()))
        ax.set_title(title,fontsize=10); ax.spines[['top','right']].set_visible(False)
        for i,v in enumerate(means): ax.text(i,v+errors[i],f'{v:.4f}',ha='center',va='bottom',fontsize=9)
    fig.suptitle(f"QM9S 1000 | 800/100/100 split | 5 paired seeds | {r['selected_config']}",fontsize=11)
    fig.tight_layout(); fig.savefig(out/'comparison.png',dpi=180); plt.close(fig)
    grid=np.asarray(bundle['energy_eV']); target=np.asarray(bundle['target'])*bundle['normalization_scale']
    preds={arm:np.mean([np.asarray(bundle['predictions'][f'{arm}_{s}']) for s in r['seeds']],axis=0)*bundle['normalization_scale'] for arm in colors}
    fig,axes=plt.subplots(2,2,figsize=(11,7))
    # First four frozen test identities, not selected based on model success.
    for index,ax in enumerate(axes.flat):
        ax.plot(grid,target[index],color='#333333',lw=1.5,label='Source spectrum')
        for arm,color in colors.items(): ax.plot(grid,preds[arm][index],color=color,label=arm,lw=1.2)
        ax.set_title(f"Frozen test molecule ID {bundle['ids'][index]}")
        ax.set_xlabel('Energy / eV'); ax.set_ylabel('Source spectral intensity')
        ax.spines[['top','right']].set_visible(False)
    axes[0,0].legend(fontsize=8); fig.tight_layout(); fig.savefig(out/'example_spectra.png',dpi=180); plt.close(fig)
    fig,ax=plt.subplots(figsize=(8,4.5))
    for arm,color in colors.items():
        for seed in r['seeds']:
            path=ROOT/'runs'/f"{r['selected_config']}_seed{seed}"/f'{arm}_history.json'
            h=json.loads(path.read_text())
            ax.plot([x['epoch'] for x in h],[x['validation']['mse'] for x in h],color=color,alpha=.65,
                    label=arm if seed==r['seeds'][0] else None)
    ax.set(xlabel='Epoch',ylabel='Validation MSE / training RMS squared',title='Selected shared configuration: all five paired seeds')
    ax.legend(); ax.spines[['top','right']].set_visible(False); fig.tight_layout(); fig.savefig(out/'validation_curves.png',dpi=180); plt.close(fig)
    low,high=r['paired_molecule_bootstrap_95ci']; improvement=r['mto_mse_relative_improvement_percent']
    if high<0 and r['mto_better_test_mse_seed_count']>=4:
        conclusion='本轮结果初步支持 MTO 在这一小样本、同分布直接光谱任务中有益。'
    elif low>0:
        conclusion='本轮结果不支持 MTO 带来收益；在当前设置下，MTO 的测试 MSE 更高。'
    else:
        conclusion='当前差异尚不足以稳定证明 MTO 优于普通汇总；应保留不确定或负面结论。'
    lines=['# QM9S 1000 分子：DetaNet 与 DetaNet＋MTO 对照','',conclusion,'',
           f"共同配置：`{r['selected_config']}`。800/100/100 划分，5 个配对种子，参数量匹配；只以验证集选择配置和 checkpoint。",'',
           '| 测试指标 | DetaNet | DetaNet＋MTO |','|---|---:|---:|']
    for key,label in [('mse','归一化 MSE'),('rmse','逐分子 RMSE 均值'),('cosine','Cosine'),('pearson','Pearson')]:
        cells=[]
        for arm in ['baseline','mto']:
            a=r['aggregate'][arm][key]; cells.append(f"{a['mean']:.6f} ± {a['std_across_seeds']:.6f}")
        lines.append(f'| {label} | '+ ' | '.join(cells)+' |')
    lines+=['',f'MTO 的平均测试 MSE 相对改善为 **{improvement:.2f}%**（负值表示更差）；{r["mto_better_test_mse_seed_count"]}/5 个种子较好。',
            f'按测试分子配对、先对种子取平均的 MSE 差（MTO−baseline）95% bootstrap 区间：[{low:.6f}, {high:.6f}]。该区间以固定训练集和已拟合模型为条件。','',
            '这项结果只检验当前 1000 分子、一个随机划分和所实现的读出方式，不能证明普遍泛化优势，也不说明 MTO 是真实轨道。',
            'baseline 是相同 DetaNet backbone 的不变汇总直接光谱模型；为公平匹配参数量，两组读出隐层宽度不同，详见各 run 的 experiment.json。',
            '原始谱来自已有 601 点 CSV，未用逐态能量／偶极重构监督；强度保留源文件单位，训练仅做训练集全局 RMS 缩放。','',
            '![测试比较](comparison.png)','','![固定测试样例](example_spectra.png)','','![验证曲线](validation_curves.png)']
    (out/'comparison_report.md').write_text('\n'.join(lines),encoding='utf-8')
    archive=Path('/tmp/sczc698_MTO_20260913/MTO_complete.tar.gz')
    with tarfile.open(archive,'w:gz',dereference=True) as tar:
        for name in ['src','scripts','configs','tests','data','runs','results','jobs','README.md','backbone_provenance.json','storage.json']:
            path=ROOT/name
            if path.exists(): tar.add(path,arcname='MTO/'+name,filter=lambda info:None if '__pycache__' in info.name else info)
    return str(archive)


if __name__=='__main__': print(make_report())
