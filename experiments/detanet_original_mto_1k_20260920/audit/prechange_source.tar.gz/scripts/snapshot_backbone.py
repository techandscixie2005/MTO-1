import hashlib,json
from pathlib import Path
import shutil

root=Path(__file__).resolve().parents[1]
source=Path('/data/run01/sczc698/DetaNet-main/detanet_model')
target=root/'src/detanet_backbone'
files={}
for p in source.rglob('*.py'):
    relative=p.relative_to(source)
    files[str(relative)]=hashlib.sha256(p.read_bytes()).hexdigest()
    text=p.read_text()
    if relative.as_posix()=='__init__.py': text='from .detanet import DetaNet\n'
    if relative.as_posix()=='modules/update.py':
        text=text.replace('scatter(src=mijt,index=j,dim=0)','scatter(src=mijt,index=j,dim=0,dim_size=T.shape[0])')
        text=text.replace('scatter(src=mijs,index=j,dim=0)','scatter(src=mijs,index=j,dim=0,dim_size=S.shape[0])')
    out=target/relative; out.parent.mkdir(parents=True,exist_ok=True); out.write_text(text)
shutil.copy2(source.parent/'LICENSE',target/'LICENSE')
provenance={'source':str(source),'original_hashes':files,'common_changes_for_both_models':[
    'Minimal __init__, isolated-atom scatter dim_size, .to-compatible buffers in adapter',
    'Latent mode with scale=None; no pretrained checkpoints',
    'Explicit geometry radius graph, no default neighbor cap',
    'Both arms use identical irrep RMS normalization and backbone initial weights'],
    'source_tree_sha256':hashlib.sha256(json.dumps(files,sort_keys=True).encode()).hexdigest()}
(root/'backbone_provenance.json').write_text(json.dumps(provenance,indent=2))
print('Backbone copied; originals untouched',provenance['source_tree_sha256'])
