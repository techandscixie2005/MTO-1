"""Finite workflow: pilot completion -> validation freeze -> replication -> test.

Only this project's jobs are submitted/observed. Stop on a failed/missing job.
No automatic retries or unbounded hyperparameter search.
"""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
STATE=ROOT/'results/workflow.json'


def save(stage,**kwargs):
    STATE.write_text(json.dumps({'stage':stage,'updated_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),**kwargs},indent=2))


def wait_jobs(jobs):
    while True:
        pending=[]
        for job in jobs:
            folder=ROOT/'runs'/f"{job['config']}_seed{job['seed']}"
            if (folder/'DONE').exists(): continue
            result=subprocess.run(['sacct','-j',job['job_id'],'--format=State','-n','-X'],capture_output=True,text=True,check=True)
            state=result.stdout.strip().split()[0] if result.stdout.strip() else 'UNKNOWN'
            if any(state.startswith(s) for s in ['FAILED','CANCELLED','TIMEOUT','OUT_OF_MEMORY','NODE_FAIL','COMPLETED']):
                raise RuntimeError(f"Pair missing DONE: {job}, scheduler state={state}")
            pending.append({**job,'state':state})
        if not pending: return
        save('waiting_for_pairs',pending=pending)
        time.sleep(30)


def main():
    try:
        if (ROOT/'results/comparison.json').exists():
            save('complete',comparison='results/comparison.json'); return
        pilot=json.loads((ROOT/'jobs/pilot.json').read_text())
        wait_jobs(pilot)
        subprocess.run([sys.executable,'scripts/select_config.py'],cwd=ROOT,check=True)
        selection=json.loads((ROOT/'results/selection.json').read_text())
        registry=ROOT/'jobs/confirmatory.json'
        if registry.exists(): jobs=json.loads(registry.read_text())
        else:
            jobs=[]
            for seed in selection['confirmatory_seeds']:
                result=subprocess.run(['sbatch','--parsable','scripts/train.slurm',selection['selected_config'],str(seed)],
                                      cwd=ROOT,check=True,capture_output=True,text=True)
                jobs.append({'config':selection['selected_config'],'seed':seed,'job_id':result.stdout.strip().split(';')[0]})
                registry.write_text(json.dumps(jobs,indent=2))
        wait_jobs(jobs)
        save('evaluating_frozen_test',selection=selection['selected_config'])
        subprocess.run([sys.executable,'scripts/evaluate_selected.py'],cwd=ROOT,check=True,
                       env={**os.environ,'PYTHONPATH':str(ROOT/'src'),'OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1'})
        save('complete',comparison='results/comparison.json')
    except Exception as exc:
        save('failed',error=str(exc)); raise


if __name__=='__main__': main()
