"""Uniform QM9S identity sample with audited geometry/spectrum row alignment."""
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path
import random
import zipfile
from rdkit import Chem
from restricted_qm9s import MetadataReader,decode

ROOT=Path(__file__).resolve().parents[1]
SOURCE=Path('/data/run01/sczc698/czl/detanet-new/qm9s.pt')
SPEC=Path('/data/run01/sczc698/czl/shuju-323-527-fuwuqi/323/shuju/1.5-13.5ev-uvis.csv')
SMILES=SPEC.parent/'UV-Vis.txt'
SEED=20260914


def canonical(s):
    m=Chem.MolFromSmiles(s)
    if m is None: raise ValueError('Invalid SMILES: '+s)
    return Chem.MolToSmiles(m,canonical=True,isomericSmiles=True)


def main():
    out=ROOT/'data'; out.mkdir(exist_ok=True)
    spectrum_smiles=SMILES.read_text().splitlines()
    with gzip.open(ROOT.parent/'data/qm9s_uv1000.json.gz','rt') as f: prior=json.load(f)
    prior_ids={r['canonical_smiles'] for r in prior}
    with zipfile.ZipFile(SOURCE) as z:
        meta=next(n for n in z.namelist() if n.endswith('data.pkl'))
        prefix=meta[:-8]
        with z.open(meta) as stream: records=MetadataReader(stream).load()
        print('source_records',len(records),'spectrum_smiles',len(spectrum_smiles),flush=True)
        if len(records)!=len(spectrum_smiles): raise ValueError('Source lengths differ; cannot assume row alignment')
        order=list(range(len(records))); random.Random(SEED).shuffle(order)
        selected={}; seen=set(); excluded=[]
        for index in order:
            record=records[index]
            d=record.__dict__.get('_store',record).__dict__.get('_mapping',record.__dict__)
            smi=d['smile']; identity=canonical(smi)
            if identity in prior_ids: continue
            if identity!=canonical(spectrum_smiles[index]):
                raise ValueError(f'Geometry and spectrum SMILES mismatch at source row {index}')
            if identity in seen:
                excluded.append({'source_index':index,'reason':'duplicate_canonical_identity'}); continue
            molecule={k:decode(d[k],z,prefix) for k in ('z','pos','number')}
            if any(a not in [1,6,7,8,9] for a in molecule['z']): raise ValueError('Unexpected element')
            if any(not math.isfinite(v) for xyz in molecule['pos'] for v in xyz): raise ValueError('Invalid geometry')
            mol=Chem.MolFromSmiles(identity)
            if Chem.GetFormalCharge(mol)!=0 or any(a.GetNumRadicalElectrons() for a in mol.GetAtoms()):
                excluded.append({'source_index':index,'reason':'outside_neutral_closed_shell_scope'}); continue
            molecule.update(source_index=index,smile=smi,canonical_smiles=identity)
            selected[index]=molecule; seen.add(identity)
            if len(selected)==10000: break
        source_records=len(records)
        del records
    digest=hashlib.sha256()
    row_count=0
    with SPEC.open() as stream:
        header=stream.readline(); digest.update(header.encode())
        columns=next(csv.reader([header])); grid=[float(v) for v in columns[1:]]
        if len(grid)!=601 or abs(grid[0]-1.5)>1e-8 or abs(grid[-1]-13.5)>1e-8:
            raise ValueError('Unexpected UV energy grid')
        for index,line in enumerate(stream):
            digest.update(line.encode()); row_count+=1
            if index not in selected: continue
            fields=next(csv.reader([line]))
            if int(fields[0])!=index: raise ValueError('Unexpected spectrum index')
            spectrum=[float(v) for v in fields[1:]]
            if len(spectrum)!=len(grid) or any(not math.isfinite(v) or v<0 for v in spectrum):
                raise ValueError('Malformed/nonfinite/negative spectrum')
            if max(spectrum)<=0: raise ValueError('Empty spectrum; do not silently substitute another molecule')
            selected[index]['spectrum']=spectrum
    if row_count!=source_records: raise ValueError('Spectrum row count differs from geometry dataset')
    sampled=list(selected.values())
    if len(sampled)!=10000 or any('spectrum' not in r for r in sampled): raise ValueError('Incomplete extraction')
    split_rng=random.Random(SEED+1); split_rng.shuffle(sampled)
    for i,r in enumerate(sampled): r['split']='train' if i<8000 else 'validation' if i<9000 else 'test'
    train=sampled[:8000]
    values=[v for r in train for v in r['spectrum']]
    scale=math.sqrt(sum(v*v for v in values)/len(values))
    atom_counts=sorted(len(r['z']) for r in train)
    manifest={
        'sampling_seed':SEED,'split_seed':SEED+1,'count':10000,'splits':{'train':8000,'validation':1000,'test':1000},
        'source_geometry':str(SOURCE),'source_spectrum':str(SPEC),'source_spectrum_smiles':str(SMILES),
        'source_records':source_records,'spectrum_rows':row_count,'unique_canonical_identities':len(seen),
        'selected_alignment_checks_passed':10000,'excluded_before_10000':excluded,'excludes_all_prior_1000_identities':True,
        'source_spectrum_sha256':digest.hexdigest(),'source_geometry_bytes':SOURCE.stat().st_size,
        'source_geometry_mtime_ns':SOURCE.stat().st_mtime_ns,
        'energy_grid_eV':grid,'target':'existing_broadened_UV_Vis_spectrum',
        'grid_evidence':'CSV numeric column header 1.5..13.5 with step 0.02',
        'target_intensity_units':'source CSV units; absolute cross-section calibration not asserted',
        'broadening_protocol':'inherited from source CSV; no rebroadened or reconstructed roots',
        'labels_used':['spectrum'],'model_inputs':['z','pos','geometry-derived edges'],
        'pretraining':'none; all models initialized from scratch',
        'normalization':'single global RMS fitted on 8000 training spectra; no per-molecule normalization',
        'train_spectrum_rms':scale,'train_median_atoms':(atom_counts[3999]+atom_counts[4000])/2,
        'source_backbone_unchanged':True,
    }
    payload=json.dumps(sampled,separators=(',',':')).encode()
    manifest['sample_sha256']=hashlib.sha256(payload).hexdigest()
    with gzip.open(out/'qm9s_uv10000.json.gz','wb') as f: f.write(payload)
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2))
    (out/'splits.json').write_text(json.dumps({s:[r['number'] for r in sampled if r['split']==s]
                                            for s in ('train','validation','test')},indent=2))
    print(json.dumps({k:v for k,v in manifest.items() if k!='energy_grid_eV'},indent=2),flush=True)


if __name__=='__main__': main()
