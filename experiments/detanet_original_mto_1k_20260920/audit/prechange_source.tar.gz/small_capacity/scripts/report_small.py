import json
from pathlib import Path


def make_report(root):
    root=Path(root)
    r=json.loads((root/'results/comparison.json').read_text())
    s=json.loads((root/'results/selection.json').read_text())
    m=json.loads((root/'data/manifest.json').read_text())
    lines=['# 小参数 DetaNet 与 MTO 光谱对照实验', '',
           f"分子数：{m['count']}；划分：{m['splits']}。仅光谱监督，从零训练。", '',
           f"验证集选定配置：`{r['selected_config']}`；随机种子：{r['seeds']}。", '',
           '| 模型 | 参数量 | 测试 MSE（均值 ± 种子标准差） | 光谱余弦相似度 |',
           '|---|---:|---:|---:|']
    for arm in ['baseline','mto']:
        a=r['aggregate'][arm]
        p=next(x['parameters'] for x in r['per_seed'] if x['arm']==arm)
        lines.append(f"| {arm} | {p} | {a['mse']['mean']:.6f} ± {a['mse']['std_across_seeds']:.6f} | {a['cosine']['mean']:.6f} |")
    lines += ['', f"MTO 测试 MSE 相对改善：{r['mto_mse_relative_improvement_percent']:.2f}%；"
              f"{r['mto_better_test_mse_seed_count']}/{len(r['seeds'])} 个种子改善。",
              f"训练集均值光谱预测器测试 MSE：{r['train_mean_spectrum_baseline']['mse']:.6f}。", '',
              '## 各容量的验证集筛选（两个预实验种子）', '',
              '| 容量 | 配置 | baseline MSE | MTO MSE | MTO 改善 |',
              '|---|---|---:|---:|---:|']
    for c in s['capacity_winners']:
        lines.append(f"| {c['capacity']} | {c['config']} | {c['baseline']:.6f} | {c['mto']:.6f} | {100*c['improvement']:.2f}% |")
    lines += ['', '## 解释范围', '',
              '两组使用同一 DetaNet 主干、相同主干初始化、划分、批次顺序、优化器与训练预算；'
              '池化模块不同，预测头隐藏宽度用于匹配有效参数量，差异小于 1%。',
              '两组均通过固定的 32 个高斯基函数输出 601 点光谱，全部 601 点参与损失。'
              '因此与旧版 10.7 万参数实验的差异同时涉及容量和光谱解码器。',
              '原 1000 分子测试集此前已经查看，该数据集的新结果仍属探索性复用；'
              '10000 分子扩展若启动，将排除原来的全部 1000 个分子身份，并保留新的测试集。',
              'MTO 的谱模态是可学习的潜变量，不应直接解释为真实电子激发态。',
              f"分子配对 bootstrap 的 MTO-baseline MSE 95% 区间：{r['paired_molecule_bootstrap_95ci']}。"
              '该区间以本次固定划分和已训练模型为条件，不表示跨训练数据集的不确定性。',
              f"10000 分子扩展决定：{s.get('expand_to_10000',False)}；只根据验证集预设规则决定。", '']
    (root/'results/REPORT.md').write_text('\n'.join(lines),encoding='utf-8')
