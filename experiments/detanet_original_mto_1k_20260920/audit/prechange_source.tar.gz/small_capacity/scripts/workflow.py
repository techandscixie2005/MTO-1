"""Bounded Slurm DAG: paired pilots -> validation selection -> replication -> test.
Only validation can trigger the predeclared, independent 10000-molecule extension.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import statistics
import subprocess
import sys
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[1]
PY='/data/run01/sczc698/.conda/envs/cheng/bin/python'


def read(path): return json.loads(path.read_text())


def write(path,obj):
    tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(obj,indent=2))
    tmp.replace(path)


def record(key,value):
    path=ROOT/'results/workflow.json'
    state=read(path) if path.exists() else {}
    state[key]=value
    state['updated_utc']=datetime.now(timezone.utc).isoformat()
    write(path,state)


def run(script,*args):
    subprocess.run([PY,str(ROOT/'scripts'/script),*map(str,args)],check=True)


def submit(stage,dependency=None,array=None,root=None):
    root=Path(root or ROOT)
    cmd=['sbatch','--parsable','--partition=gpu','--gpus=1','--cpus-per-task=4',
         '--time=24:00:00','--job-name=mto_small_'+stage,
         '--output='+str(root/'logs'/f'{stage}_%A_%a.out'),
         '--error='+str(root/'logs'/f'{stage}_%A_%a.err')]
    if dependency: cmd+=['--dependency=afterok:'+str(dependency),'--kill-on-invalid-dep=yes']
    if array: cmd+=['--array='+array]
    cmd+=[str(root/'jobs/stage.sh'),str(root),stage]
    job=subprocess.check_output(cmd,text=True).strip().split(';')[0]
    if not job.isdigit(): raise RuntimeError('Unexpected sbatch response: '+job)
    return job


def launch():
    if (ROOT/'results/workflow.json').exists(): raise RuntimeError('Already launched; inspect before resubmitting')
    grid=read(ROOT/'configs/grid.json')
    if not read(ROOT/'results/model_tests.json')['passed']: raise RuntimeError('Audit required')
    count=len(grid['configs'])*len(grid['seeds'])
    pilot=submit('pilot',array=f'0-{min(4,count)-1}%4')
    record('pilot_job',pilot)
    selection=submit('select',dependency=pilot)
    record('selection_job',selection)
    record('status','pilots_submitted')
    print(read(ROOT/'results/workflow.json'),flush=True)


def select():
    grid=read(ROOT/'configs/grid.json'); manifest=read(ROOT/'data/manifest.json')
    rows=[]
    for cfg in grid['configs']:
        values={a:[] for a in ['baseline','mto']}
        for seed in grid['seeds']:
            d=ROOT/'runs'/f"{cfg['name']}_seed{seed}"
            if not (d/'DONE').exists(): raise RuntimeError('Incomplete pilot '+str(d))
            for a in values: values[a].append(read(d/f'{a}_summary.json')['best_validation_mse'])
        b,m=[statistics.mean(values[a]) for a in ['baseline','mto']]
        rows.append(dict(config=cfg['name'],capacity=cfg['capacity'],baseline=b,mto=m,joint=(b+m)/2,
                         improvement=(b-m)/b,seed_improvements=[(x-y)/x for x,y in zip(values['baseline'],values['mto'])]))
    winners=[min([r for r in rows if r['capacity']==c],key=lambda r:r['joint'])
             for c in dict.fromkeys(r['capacity'] for r in rows)]
    chosen=min(winners,key=lambda r:r['joint'])
    naive=read(ROOT/'results/model_tests.json')['training_mean_validation_mse']
    adequate=any(r['baseline']<=.8*naive and r['mto']<=.8*naive for r in winners)
    signal=any(r['improvement']>=.02 and min(r['seed_improvements'])>=0 for r in winners)
    expand=manifest['count']==1000 and (not adequate or not signal)
    selection=dict(selected_config=chosen['config'],database_sha256=manifest['sample_sha256'],
                   all_pilots=rows,capacity_winners=winners,training_mean_validation_mse=naive,
                   adequate_prediction=adequate,stable_pilot_mto_signal=signal,expand_to_10000=expand,
                   rule=grid['selection_rule'],test_used=False)
    selection['selection_sha256']=hashlib.sha256(json.dumps(selection,sort_keys=True).encode()).hexdigest()
    write(ROOT/'results/selection.json',selection)
    conf=submit('confirm',array=f"0-{len(grid['confirmatory_seeds'])-1}%3")
    record('confirmation_job',conf)
    final=submit('finalize',dependency=conf)
    record('finalization_job',final)
    if expand:
        tenk=ROOT/'tenk'
        for folder in ['configs','data','results','logs','jobs','runs']:
            (tenk/folder).mkdir(parents=True,exist_ok=True)
        for folder in ['src','scripts','tests']:
            shutil.copytree(ROOT/folder,tenk/folder,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
        shutil.copy2(ROOT/'jobs/stage.sh',tenk/'jobs/stage.sh')
        expanded=json.loads(json.dumps(grid))
        expanded.update(experiment='QM9S-10000-small-capacity-v2',data_file='qm9s_uv10000.json.gz',
                        test_status='New independent split; all prior 1000 molecular identities excluded; test opened only after selection.')
        expanded['configs']=[c for c in grid['configs'] if c['name'] in {r['config'] for r in winners}]
        expanded['shared_training']['batch_size']=64
        expanded['parent_selection_sha256']=selection['selection_sha256']
        expanded['expansion_gate']='No further expansion. Learning rates frozen from the 1000-molecule validation pilots.'
        write(tenk/'configs/grid.json',expanded)
        prep=submit('prepare',root=tenk)
        record('expansion_preparation_job',prep)
    record('selected_config',chosen['config'])
    record('expand_to_10000',expand)
    record('status','replication_submitted')
    print(json.dumps(selection,indent=2),flush=True)


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('stage',choices=['launch','pilot','select','confirm','finalize','prepare'])
    stage=ap.parse_args().stage
    if stage=='launch': launch()
    elif stage=='select': select()
    elif stage=='pilot':
        grid=read(ROOT/'configs/grid.json')
        tasks=[(c['name'],s) for c in grid['configs'] for s in grid['seeds']]
        index=int(os.environ['SLURM_ARRAY_TASK_ID'])
        for cfg,seed in tasks[index::min(4,len(tasks))]:
            run('train_pair.py','--config',cfg,'--seed',seed)
    elif stage=='confirm':
        grid=read(ROOT/'configs/grid.json'); selected=read(ROOT/'results/selection.json')['selected_config']
        seed=grid['confirmatory_seeds'][int(os.environ['SLURM_ARRAY_TASK_ID'])]
        run('train_pair.py','--config',selected,'--seed',seed)
    elif stage=='prepare':
        run('prepare_expansion.py')
        subprocess.run([PY,str(ROOT/'tests/audit_small.py')],check=True)
        launch()
    elif stage=='finalize':
        run('evaluate_selected.py')
        record('status','complete')


if __name__=='__main__': main()
