#!/bin/bash
set -euo pipefail
cd "$1"
export PYTHONPATH="$1/src"
export OMP_NUM_THREADS=2
export MKL_NUM_THREADS=2
export OPENBLAS_NUM_THREADS=1
export PYTHONUNBUFFERED=1
exec /data/run01/sczc698/.conda/envs/cheng/bin/python "$1/scripts/workflow.py" "$2"
