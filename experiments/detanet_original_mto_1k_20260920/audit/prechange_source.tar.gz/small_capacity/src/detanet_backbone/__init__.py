from .detanet import DetaNet
