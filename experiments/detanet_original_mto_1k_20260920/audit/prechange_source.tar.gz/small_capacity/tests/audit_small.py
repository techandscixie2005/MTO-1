import json
from pathlib import Path
import torch
from e3nn import o3
from models import build_pair,spectral_basis
from dataset import load_database,collate

root=Path(__file__).resolve().parents[1]
torch.set_num_threads(1)
grid=json.loads((root/'configs/grid.json').read_text())
manifest=json.loads((root/'data/manifest.json').read_text())
graphs=load_database(root/'data'/grid.get('data_file','qm9s_uv1000.json.gz'))
scale=manifest['train_spectrum_rms']
train=[g for g in graphs if g['split']=='train']; val=[g for g in graphs if g['split']=='validation']
basis=spectral_basis().double()
floors={}; positive_errors={}
for name,part in [('train',train),('validation',val)]:
    y=torch.stack([g['spectrum'] for g in part]).double()/scale
    coefficients=torch.linalg.lstsq(basis.T,y.T).solution.T
    residual=(coefficients@basis-y).square().mean()
    floors[name]=float(residual)
    # Feasible nonnegative coefficients, checked without opening test spectra.
    gram=basis@basis.T; cross=y@basis.T
    step=1/torch.linalg.eigvalsh(gram).max()
    positive=coefficients.clamp_min(0)
    for _ in range(1500):
        positive=(positive-step*(positive@gram-cross)).clamp_min(0)
    positive_errors[name]=float((positive@basis-y).square().mean())
mean=torch.stack([g['spectrum'] for g in train]).mean(0)/scale
valy=torch.stack([g['spectrum'] for g in val])/scale
mean_mse=float((valy-mean).square().mean())
report={'fixed_basis':'32 analytic Gaussian functions; sigma=0.30 eV; no data-fitted parameters',
        'basis_unconstrained_least_squares_lower_bound_mse':floors,
        'basis_feasible_nonnegative_fit_mse':positive_errors,
        'basis_floor_scope':'A lower bound only: negative coefficients are allowed in this audit but not model output.',
        'training_mean_validation_mse':mean_mse,'counts':{},'tests':[]}
if positive_errors['validation']>0.10*mean_mse:
    raise RuntimeError('Fixed basis too restrictive; reassess before training')
x,_=collate(train[:3]); x['pos']=x['pos'].double()
r=-o3.rand_matrix(dtype=torch.float64)
perm=torch.randperm(len(x['z'])); inverse=torch.argsort(perm)
for cfg in {c['capacity']:c for c in grid['configs']}.values():
    pair,counts=build_pair(cfg,manifest['train_median_atoms'],seed=11)
    report['counts'][cfg['capacity']]=counts
    for arm,model in pair.items():
        model.double().eval()
        y=model(**x)
        xr={**x,'pos':x['pos']@r.T+x['pos'].new_tensor([1,2,3])}
        torch.testing.assert_close(model(**xr),y,atol=3e-6,rtol=3e-6)
        xp={**x,'z':x['z'][perm],'pos':x['pos'][perm],'batch':x['batch'][perm],'edge_index':inverse[x['edge_index']]}
        torch.testing.assert_close(model(**xp),y,atol=3e-6,rtol=3e-6)
        y.square().mean().backward()
        assert all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
        assert y.shape==(3,601) and (y>=0).all()
    report['tests'].append(cfg['capacity']+': symmetry, permutation, gradients, parameter match passed')
report['passed']=True
(root/'results/model_tests.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2),flush=True)
