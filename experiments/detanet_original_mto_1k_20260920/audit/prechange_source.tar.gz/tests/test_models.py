import json
from pathlib import Path
import unittest
import torch
from e3nn import o3
from models import build_pair
from dataset import collate

ROOT=Path(__file__).resolve().parents[1]
torch.set_num_threads(1)


class ModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cfg=json.loads((ROOT/'configs/grid.json').read_text())['configs'][0]
        cls.models,cls.counts=build_pair(cfg,18,seed=11)
        cls.graphs=[]
        for pos,z in [([[0.,0.,0.],[.7,.6,0.],[-.7,.6,0.]],[8,1,1]),
                      ([[0.,0.,0.],[1.,1.,1.],[-1.,-1.,1.],[-1.,1.,-1.],[1.,-1.,-1.]],[6,1,1,1,1])]:
            p=torch.tensor(pos,dtype=torch.float64); n=len(z)
            cls.graphs.append({'pos':p,'z':torch.tensor(z),'edge_index':(~torch.eye(n,dtype=torch.bool)).nonzero().T,
                               'spectrum':torch.zeros(601)})
        for model in cls.models.values(): model.double().eval()

    def test_parameter_match_and_initial_backbone(self):
        self.assertLess(self.counts['relative_gap'],0.01)
        for key,value in self.models['mto'].backbone.state_dict().items():
            torch.testing.assert_close(value,self.models['baseline'].backbone.state_dict()[key])
        print('PARAMETERS',json.dumps(self.counts),flush=True)

    def test_symmetry_batching_and_gradients(self):
        x,_=collate(self.graphs)
        rotation=-o3.rand_matrix(dtype=torch.float64)
        for model in self.models.values():
            p=model(**x)
            transformed={**x,'pos':x['pos']@rotation.T+torch.tensor([4.,2.,-1.])}
            torch.testing.assert_close(model(**transformed),p,atol=2e-6,rtol=2e-6)
            single,_=collate(self.graphs[:1]); torch.testing.assert_close(model(**single)[0],p[0],atol=2e-6,rtol=2e-6)
            perm=torch.randperm(len(x['z'])); inverse=torch.argsort(perm)
            permuted={**x,'z':x['z'][perm],'pos':x['pos'][perm],'batch':x['batch'][perm],
                      'edge_index':inverse[x['edge_index']]}
            torch.testing.assert_close(model(**permuted),p,atol=2e-6,rtol=2e-6)
            self.assertTrue(bool((p>=0).all()))
            model.zero_grad(); p.square().mean().backward()
            for param in model.parameters():
                self.assertIsNotNone(param.grad)
                self.assertTrue(bool(torch.isfinite(param.grad).all()))

    def test_mto_assembly_and_independent_coefficients(self):
        x,_=collate(self.graphs)
        _,export=self.models['mto'](**x,export=True)
        gates=export['gates']
        self.assertEqual(tuple(gates.shape),(8,5,3,4))
        self.assertFalse(torch.allclose(gates[:,:,0],gates[:,:,2]))
        self.assertFalse(torch.allclose(gates[:,0],gates[:,1]))
        self.assertTrue(bool((gates.abs()<=1).all()))


if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ModelTests))
    (ROOT/'results').mkdir(exist_ok=True)
    (ROOT/'results/model_tests.json').write_text(json.dumps({'passed':result.wasSuccessful(),'tests':result.testsRun,
                         'errors':len(result.errors),'failures':len(result.failures)},indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
