"""DetaNet backbone with parameter-matched direct spectrum readouts.

Baseline: invariant sum pooling of scalar/vector/tensor features.
MTO: type/channel-specific signed atomic assembly into molecular modes.
Modes are latent spectrum factors, not supervised excited-state labels or MOs.
"""
import math
import torch
from torch import nn
from torch.nn import functional as F
from detanet_backbone import DetaNet


def pool(x,batch,n):
    return x.new_zeros((n,)+x.shape[1:]).index_add(0,batch,x)


def invariants(m):
    return torch.cat([m['0e'].squeeze(-1),m['1o'].square().mean(-1),m['2e'].square().mean(-1)],-1)


class Backbone(nn.Module):
    def __init__(self,cfg):
        super().__init__()
        self.c=cfg['features']
        self.core=DetaNet(num_features=self.c,num_block=cfg['blocks'],maxl=2,
            num_radial=16,attention_head=4,rc=5.0,max_atomic_number=9,
            scalar_outsize=0,irreps_out=None,out_type='latent',summation=False,
            scale=None,device=torch.device('cpu'))
        for module,key in [(self.core.Embedding,'elec'),(self.core,'mass')]:
            value=getattr(module,key); delattr(module,key); module.register_buffer(key,value)

    def forward(self,z,pos,edge_index,batch):
        s,t=self.core(z=z,pos=pos,edge_index=edge_index,batch=batch)
        c=self.c
        h={'0e':s[...,None],'1o':t[:,:3*c].reshape(-1,c,3),'2e':t[:,3*c:8*c].reshape(-1,c,5)}
        return {key:value/value.square().mean((-2,-1),keepdim=True).add(1e-8).sqrt() for key,value in h.items()}


class InvariantPooling(nn.Module):
    def __init__(self,cfg,n_ref):
        super().__init__()
        self.gamma=1/math.sqrt(n_ref)
        self.output_dim=3*cfg['features']+6

    def forward(self,h,z,batch,n,export=False):
        m={key:self.gamma*pool(value,batch,n) for key,value in h.items()}
        counts=pool(h['0e'].new_ones((len(z),1)),batch,n)
        elems=pool((z[:,None]==z.new_tensor([1,6,7,8,9])).to(h['0e'].dtype),batch,n)
        return torch.cat([invariants(m),counts.log1p(),elems],-1),({'pooled_tensors':m} if export else None)


class MolecularTensorOrbitals(nn.Module):
    def __init__(self,cfg,n_ref):
        super().__init__()
        self.channels=cfg.get('mto_channels',4)
        self.modes=cfg.get('mto_modes',4)
        c=self.channels; f=cfg['features']; q=8; hidden=32
        self.gamma=1/math.sqrt(n_ref)
        self.project=nn.ModuleDict({t:nn.Linear(f,c,bias=False) for t in ('0e','1o','2e')})
        self.query=nn.Embedding(self.modes+1,q)
        self.router=nn.Sequential(nn.Linear(6*f+6+q,hidden),nn.SiLU(),nn.Linear(hidden,hidden),nn.SiLU(),nn.Linear(hidden,3*c))
        nn.init.normal_(self.router[-1].weight,std=0.03)
        nn.init.normal_(self.router[-1].bias,std=0.02)
        self.output_dim=(self.modes*6+3)*c

    def forward(self,h,z,batch,n,export=False):
        u=invariants(h)
        counts=pool(u.new_ones((len(z),1)),batch,n)
        elems=(z[:,None]==z.new_tensor([1,6,7,8,9])).to(u.dtype)
        g=torch.cat([pool(u,batch,n)/counts,counts.log1p(),pool(elems,batch,n)],-1)
        context=torch.cat([u,g[batch]],-1)
        inp=torch.cat([context[:,None].expand(-1,self.modes+1,-1),
                       self.query.weight[None].expand(len(z),-1,-1)],-1)
        gates=self.router(inp).tanh().reshape(len(z),self.modes+1,3,self.channels)
        m,terms={},{}
        for index,t in enumerate(('0e','1o','2e')):
            b=self.project[t](h[t].transpose(-1,-2)).transpose(-1,-2)
            f=gates[:,:,index,:,None]*b[:,None]
            m[t]=self.gamma*pool(f,batch,n)
            if export: terms[t]=f
        inv=invariants(m)
        # Same-type contractions are legal scalar CG relations to reference mode.
        cross=torch.cat([(m[t][:,:1]*m[t][:,1:]).mean(-1) for t in ('0e','1o','2e')],-1)
        latent=torch.cat([inv[:,0],inv[:,1:].flatten(1),cross.flatten(1)],-1)
        return latent,({'mto':m,'assembly':terms,'gates':gates} if export else None)


def make_head(n_in,hidden,n_out):
    return nn.Sequential(nn.LayerNorm(n_in),nn.Linear(n_in,hidden),nn.SiLU(),nn.Linear(hidden,n_out))


class SpectrumModel(nn.Module):
    def __init__(self,cfg,n_ref,bins=601,variant='mto',baseline_hidden=None):
        super().__init__()
        self.backbone=Backbone(cfg)
        self.variant=variant
        if variant=='mto': self.readout=MolecularTensorOrbitals(cfg,n_ref)
        elif variant=='baseline': self.readout=InvariantPooling(cfg,n_ref)
        else: raise ValueError(variant)
        hidden=cfg.get('head_hidden',64) if variant=='mto' else baseline_hidden
        if hidden is None: raise ValueError('Baseline width must be parameter matched')
        self.head=make_head(self.readout.output_dim,hidden,bins)
        self.hidden=hidden
        nn.init.normal_(self.head[-1].weight,std=0.005)
        nn.init.constant_(self.head[-1].bias,-2.)

    def forward(self,z,pos,edge_index,batch,n,export=False):
        h=self.backbone(z,pos,edge_index,batch)
        latent,extra=self.readout(h,z,batch,n,export=export)
        spectrum=F.softplus(self.head(latent))
        return (spectrum,extra) if export else spectrum


def count_parameters(model): return sum(p.numel() for p in model.parameters() if p.requires_grad)


def build_pair(cfg,n_ref,bins=601,seed=11):
    torch.manual_seed(seed)
    mto=SpectrumModel(cfg,n_ref,bins,'mto')
    target=count_parameters(mto)
    shared=count_parameters(mto.backbone)
    n_in=3*cfg['features']+6
    # LayerNorm(2*n_in), two Linear layers, every parameter is active.
    hidden=min(range(8,513),key=lambda h:abs(shared+2*n_in+(n_in+1)*h+(h+1)*bins-target))
    torch.manual_seed(seed)
    baseline=SpectrumModel(cfg,n_ref,bins,'baseline',hidden)
    baseline.backbone.load_state_dict(mto.backbone.state_dict())
    counts={'mto':count_parameters(mto),'baseline':count_parameters(baseline),
            'backbone':shared,'mto_head_hidden':mto.hidden,'baseline_head_hidden':baseline.hidden}
    counts['relative_gap']=abs(counts['mto']-counts['baseline'])/counts['mto']
    if counts['relative_gap']>0.01: raise ValueError('Parameter match exceeds 1%')
    return {'baseline':baseline,'mto':mto},counts
