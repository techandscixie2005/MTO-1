# DetaNet + MTO：QM9S 1000 分子直接 UV-Vis 对照

服务器工作区：`/data/run01/sczc698/xxy/MTO`。

所有修改均在本工作区内。公用 `/data/run01/sczc698/DetaNet-main/detanet_model` 为只读来源，原始文件哈希见 `backbone_provenance.json`。上一版 `/projects/mto_uv` 不参与本轮实验。

## 问题与范围

在相同 DetaNet backbone、小数据、相同训练预算且参数量匹配的条件下，MTO 分子张量组装是否比普通不变汇总更有利于 UV-Vis 光谱预测？这是归纳偏置的小规模筛查，不预设 MTO 优于基线，也不把潜在通道解释成真实分子轨道。

## 数据

- 从 `qm9s.pt` 中固定随机种子抽取 1000 个不同 canonical molecular identities。
- 每个入选分子的 SMILES 与光谱文件同一行进行 canonical 对齐核验；保留 QM9S 自带三维坐标。
- 使用已有 `1.5-13.5ev-uvis.csv`，601 个能量网格点，直接光谱监督。
- 固定 800/100/100 train/validation/test，所有模型共享同一名单。
- 仅使用训练集拟合一个全局光谱 RMS；不对每个分子的谱分别归一化。
- 主模型输入仅含元素、坐标和坐标导出的 5 Å 图连接；不读取轨道、部分电荷、逐态能量、跃迁偶极或其他诊断作为特征／监督。
- 原始谱强度单位、展宽协议沿用源 CSV，未将其声称为已校准的绝对吸收截面。本轮不依赖未核实的跃迁偶极单位。

## 两组模型

**DetaNet baseline**：相同 DetaNet 原子张量，固定尺度 sum pooling，提取标量和向量／二阶张量范数，接普通光谱 MLP。这是为本实验构建的 direct-spectrum pooled baseline，不冒充原作者 checkpoint 的原样复现。

**DetaNet + MTO**：在同一原子张量上加入 4 个分子光谱模式及一个共享参考模式；每种张量类型有 4 个组装通道。标量 router 生成按原子、模式、类型及通道变化的 signed tanh 系数，作用于完整 irrep。汇总后使用不变量及与参考模式的同类型收缩，接光谱 MLP。输出不经过 backbone 的旁路。模式不是监督的激发态编号。

两组都能访问分子尺寸和元素计数，使用相同 backbone 初始化、优化器、学习率、weight decay、batch size、数据顺序、损失和早停规则。baseline 的**实际使用的**读出隐层宽度自动调整，使总可训练参数与 MTO 组相差不超过 1%；不会用无效参数凑数。该宽度差异是参数匹配手段，明确记录在每组 `experiment.json` 中。

32 通道的预检参数量：baseline 107045；MTO 106789；公共 backbone 52032。相差 0.24%。全部从头训练，不使用可能见过当前测试分子的预训练权重。

## 调参和评价

预先登记的三个设置与训练规则见 `configs/grid.json`。首轮 3 个设置 × 2 个配对 seeds × 2 个模型，各 pair 在同一 GPU 作业内依次运行。

每组 checkpoint 仅按 validation MSE 选择。使用两个模型、两个 pilot seeds 的平均 validation MSE 选择**同一套**超参数；冻结后补充 3 个配对 seeds，再评价固定 test。测试结果不用于再次调参。

报告源谱单位及训练尺度归一化后的 MSE/RMSE/MAE、逐分子 cosine/Pearson、跨 seed 方差，以及相同分子上的配对误差差异。100 个测试分子的结果只支持当前小样本设置下的初步判断。

## 运行

```bash
cd /data/run01/sczc698/xxy/MTO
export PYTHONPATH="$PWD/src"
PY=/data/run01/sczc698/.conda/envs/cheng/bin/python
$PY scripts/prepare_data.py
$PY tests/test_models.py
$PY scripts/submit_grid.py
# 六个 pilot pair 完成后：
$PY scripts/select_config.py
```

环境使用服务器已有 `cheng`，未安装或改动公用环境。Slurm 要求申请至少一张 GPU；训练脚本设有 30 分钟硬时限及验证早停。查看作业使用 `squeue -u sczc698`，查看日志使用本目录 `logs/`。

共享 `/data` 在启动时已满，因此 `data/`、`runs/`、`results/`、`logs/`、`jobs/` 指向登录节点 `/tmp/sczc698_MTO_20260913/` 的相应目录；代码保留在指定工作区。训练作业在各自计算节点临时目录运行，结果同步回登录节点。临时盘不保证重启后保留；1000 分子数据库和代码已另存本机，最终权重及报告也应备份。

实现状态和实际结果以 `results/`、`runs/` 中的真实输出为准。README 中的实验矩阵不是已完成实验的声明。
